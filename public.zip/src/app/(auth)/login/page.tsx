import LoginPage from '@/presentation/pages/login/Component';

export default function Page() {
    return (
        <>
            <title>Login - Dashboard Klinik</title>
            <LoginPage />
        </>
    );
}
