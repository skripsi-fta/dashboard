export default function Page() {
    return <>antrian management</>;
}
