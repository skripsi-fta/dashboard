import CheckInPage from '@/presentation/pages/dashboard/monitoring/checkin/Component';

export default function Page() {
    return (
        <>
            <CheckInPage />
        </>
    );
}
