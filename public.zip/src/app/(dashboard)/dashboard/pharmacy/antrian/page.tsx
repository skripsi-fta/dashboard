import PharmacyQueuePage from '@/presentation/pages/dashboard/farmasi/Component';

export default function Page() {
    return (
        <>
            <PharmacyQueuePage />
        </>
    );
}
