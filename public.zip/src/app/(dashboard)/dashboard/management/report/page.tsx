import ReportManagementPage from '@/presentation/pages/dashboard/management/report/Component';

export default function Page() {
    return (
        <>
            <ReportManagementPage />
        </>
    );
}
