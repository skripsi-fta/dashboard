import SpesialisasiDokterPage from '@/presentation/pages/dashboard/management/spesialisasidokter/Component';

export default function Page() {
    return (
        <>
            <SpesialisasiDokterPage />
        </>
    );
}
