import RuanganPage from '@/presentation/pages/dashboard/management/ruangan/Component';

export default function Page() {
    return <>
        <RuanganPage />
    </>;
}
