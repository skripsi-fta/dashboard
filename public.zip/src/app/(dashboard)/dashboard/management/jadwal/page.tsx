import ScheduleManagementComponent from '@/presentation/pages/dashboard/management/jadwal/Component';

export default function Page() {
    return (
        <>
            <ScheduleManagementComponent />
        </>
    );
}
