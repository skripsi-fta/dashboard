import ManagementProfilDokterPage from '@/presentation/pages/dashboard/management/profildokter/Component';

export default function Page() {
    return (
        <>
            <ManagementProfilDokterPage />
        </>
    );
}
