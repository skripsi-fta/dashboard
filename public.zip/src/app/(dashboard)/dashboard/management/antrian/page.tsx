import LiveQueuePage from '@/presentation/pages/dashboard/management/antrian/Component';

export default function Page() {
    return <LiveQueuePage />;
}
