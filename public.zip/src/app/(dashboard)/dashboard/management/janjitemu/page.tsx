import AppointmentManagementPage from '@/presentation/pages/dashboard/management/janjitemu/Component';

export default function Page() {
    return (
        <>
            < AppointmentManagementPage />
        </>
    );
}
