import ManagementUserPage from '@/presentation/pages/dashboard/management/user/Component';

export default function Page() {
    return (
        <>
            <ManagementUserPage />
        </>
    );
}
