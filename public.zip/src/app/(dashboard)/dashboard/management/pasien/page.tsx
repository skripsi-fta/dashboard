import PasienManagementComponent from '@/presentation/pages/dashboard/management/pasien/Component';

export default function Page() {
    return <PasienManagementComponent />;
}
