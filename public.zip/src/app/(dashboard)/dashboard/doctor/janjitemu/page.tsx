import ScheduleAppointmentPage from '@/presentation/pages/dashboard/dokter/janjitemu/Components';

export default function Page() {
    return <ScheduleAppointmentPage />;
}
