import ScheduleDoctorPage from '@/presentation/pages/dashboard/dokter/jadwal/Component';

export default function Page() {
    return <ScheduleDoctorPage />;
}
