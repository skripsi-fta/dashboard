import QueueCashierPage from '@/presentation/pages/dashboard/cashier/antriankasir/Component';

export default function Page() {
  return <QueueCashierPage />;
}
