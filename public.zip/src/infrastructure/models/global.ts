export namespace GlobalModels {
    export interface Dropdown {
        value: any;
        label: string;
    }

    export interface DropdownData {
        data: Dropdown[];
    }
}
