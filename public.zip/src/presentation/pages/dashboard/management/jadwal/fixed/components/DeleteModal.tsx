import React from 'react';

const DeleteModal = () => {
    return <></>;
};

export default DeleteModal;
