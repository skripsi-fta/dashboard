const CashierReportComponent = () => {
    return <>Cashier report</>;
};

export default CashierReportComponent;
