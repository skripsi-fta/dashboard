const PharmacyReportComponent = () => {
    return <>Pharmacy report</>;
};

export default PharmacyReportComponent;
