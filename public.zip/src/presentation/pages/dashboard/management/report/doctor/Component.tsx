const DoctorReportComponent = () => {
    return <>doctor report</>;
};

export default DoctorReportComponent;
